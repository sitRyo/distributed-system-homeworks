
import java.io.*;

public class MooMain {

	public static void dumpToFile(Person moo, String name) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(name));
			// System.out.println(oos);
			oos.writeObject(moo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Moo restoreFromFile(String name) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(name));
			return (Moo)ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static void main(String ...args) {
		Person moo = new Person();
		// 
		MooMain.dumpToFile(moo, "person.hex");
		System.out.println("finished dumptofile");
		Moo moo2 = MooMain.restoreFromFile("moo.hex");
		moo2.print();
	}

	
}
