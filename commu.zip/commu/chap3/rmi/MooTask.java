import java.io.*;

public class MooTask {
	public static void dumpToFile(Task moo, String name) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(name));
			// System.out.println(oos);
			oos.writeObject(moo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static MyTask restoreFromFile(String name) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(name));
			return (MyTask)ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

  public static void main(String ...args) {
    Task task = new MyTask();
    MooTask.dumpToFile(task, "task.hex");
    MyTask task2 = MooTask.restoreFromFile("task.hex");
    System.out.println(task2.str1);
    System.out.println(task2.str2);
  }
}