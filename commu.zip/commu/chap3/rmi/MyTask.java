
public class MyTask implements Task {
	
	private int status = 0;
	public String str1 = "string1";
	public String str2 = "string2";

	@Override
	public Object execute() {
		status = 1;
		return new Long(System.currentTimeMillis());
	}
	
	public int getStatus() {
		return status;
	}
	
}
