import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.locks.Condition;

public class MyServer {

  public static final int PORT = 8891;

	private String fileName = "task.hex";
	
	private ServerSocket sSocket = null;
	private Socket socket = null;
	//private BufferedReader reader = null;
	//private InputStream reader = null;
	// private DataInputStream reader = null;
	private ObjectInputStream reader = null;
	private OutputStream writer = null;

  public MyServer() {
    registorMyTask();
		createSocket();
	}

	private void hello(String str) {
		System.out.println(str);
	}
	
	private void createSocket() {
		try {
			sSocket = new ServerSocket();
			sSocket.bind(new InetSocketAddress("127.0.0.1", PORT));
	
			System.out.println("socket open!");

			System.out.println("wait new connection attempt.");
			socket = sSocket.accept();
			
			//reader = socket.getInputStream();
			/*
			reader = new BufferedReader(
				new InputStreamReader(socket.getInputStream())
			);*/
	
			System.out.println("socket reader open!");
	
			writer = socket.getOutputStream();

			System.out.println("socket writer open!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private byte[] readFile() {
		byte[] result = null;
		try {
			FileInputStream fI = new FileInputStream(fileName);
			ByteArrayOutputStream bas = new ByteArrayOutputStream();
			int n = fI.read();
			while (n != -1) {
				bas.write(n);
				n = fI.read();
			}
			result = bas.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private void sendData(byte[] data) {
		if (data == null) {
			System.err.println("data is null");
			return;
		}
		try {
			writer.write(data);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// writer.flush();
	}

	private void recvData(byte[] data) {
		System.out.println("...read");
		int cnt = 1;
		try {
			reader = new ObjectInputStream(
			socket.getInputStream()
		);
			Person person = (Person)reader.readObject();
			this.hello(person.name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.println(cnt);
	}

	public static void registorMyTask() {
    Task task = new MyTask();
    MooTask.dumpToFile(task, "task.hex");
  }

	public static void dumpToFile(Task moo, String name) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(name));
			// System.out.println(oos);
			oos.writeObject(moo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static MyTask restoreFromFile(String name) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(name));
			return (MyTask)ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

  public static void main(String ...args) {
		byte[] data = null;
		MyServer obj = new MyServer();
		obj.sendData(obj.readFile());
		obj.recvData(data);
  }
}