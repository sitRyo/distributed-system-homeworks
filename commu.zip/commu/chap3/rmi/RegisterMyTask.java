import java.io.*;

public class RegisterMyTask {
  public static void registorMyTask() {
    Task task = new MyTask();
    MooTask.dumpToFile(task, "task.hex");
  }

	public static void dumpToFile(Task moo, String name) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(name));
			// System.out.println(oos);
			oos.writeObject(moo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static MyTask restoreFromFile(String name) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(name));
			return (MyTask)ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
}