#ifndef _HEXDUMP_
#define _HEXDUMP_

#include "global.h"

void hex_dump(char* p, u32 len);

#endif