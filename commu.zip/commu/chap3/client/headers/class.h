#ifndef _CLASSHEADER_
#define _CLASSHEADER_

struct MyTask {
  unsigned char str1[10];
  unsigned char str2[10];
};

#endif