#ifndef _SOCKCLIENT_
#define _SOCKCLIENT_

#include "class.h"

struct MyTask connect_server();
static int port = 8891;
static int msgsize = 1024;

#endif
