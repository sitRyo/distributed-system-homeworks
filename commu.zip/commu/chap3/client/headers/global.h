#ifndef _GLOBAL_
#define _GLOBAL_

typedef unsigned int u32;
typedef unsigned long long u64;

#endif