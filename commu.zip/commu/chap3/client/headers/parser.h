#ifndef _PARSER_
#define _PARSER_

#include "global.h"
#include "class.h"

int recieve_first(unsigned char* p, u32 len);
int parse_contents(unsigned char* p, u32 len);
int check_object(unsigned char* p, u32 len);
int parse_classname(unsigned char* p, u32 len);
int parse_serializeUID(unsigned char* p, u32 len);
int parse_newHandle(unsigned char* p, u32 len);
int parse_classDescInfo(unsigned char* p, u32 len);
int parse_classFieldData(unsigned char* p, u32 len);

struct MyTask parse_field(unsigned char* p, u32 len);

void construct_person(unsigned char* p1, unsigned char* p2, unsigned char* p);

#endif