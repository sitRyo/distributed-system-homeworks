#ifndef _PERSON_
#define _PERSON_

char* construct_packet(unsigned char* p1, unsigned char* p2);

#endif