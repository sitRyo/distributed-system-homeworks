#ifndef _SYMBOLS_
#define _SYMBOLS_

#define STREAM_MAGIC 0xaced
#define STREAM_VERSION 0x0005 // unsinged short
#define TC_NULL 0x70
#define TC_REFERENCE 0x71
#define TC_CLASSDESC 0x72
#define TC_OBJECT 0x73
#define TC_STRING 0x74
#define TC_ARRAY 0x75
#define TC_CLASS 0x76
#define TC_BLOCKDATA 0x77
#define TC_ENDBLOCKDATA 0x78
#define TC_RESET 0x79
#define TC_BLOCKDATALONG 0x7A
#define TC_EXCEPTION 0x7B
#define TC_LONGSTRING 0x7C
#define TC_PROXYCLASSDESC 0x7D
#define TC_ENUM 0x7E

#define baseWriteHandle 0x7E0000 // int

#define SC_WRITE_METHOD 0x01
#define SC_BLOCK_DATA 0x08
#define SC_SERIALIZABLE 0x02
#define SC_EXTERNALIZABLE 0x04
#define SC_ENUM 0x10

enum prim_typecode {
  B, // byte
  C, // char
  D, // double
  F, // float
  I, // int
  J, // long
  S, // short
  Z // boolean
};

enum onj_typecode {
  // skip array
  L // object
};



#endif