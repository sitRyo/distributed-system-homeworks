#include <stdio.h>
#include "../headers/hex_dump.h"

void hex_dump(char* p, u32 len) {
  printf("\n");
  for (int i = 0; i < len; ++i) {
    if (i % 16 == 0) printf("\n");
    printf("%02x ", p[i] & 0xff);
  }
  printf("\n");
}