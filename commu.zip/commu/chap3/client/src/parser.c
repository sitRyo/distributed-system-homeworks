#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../headers/parser.h"
#include "../headers/symbols.h"
#include "../headers/hex_dump.h"


int recieve_first(unsigned char* p, u32 len) {
  // stream: magin version contents
  unsigned char p1 = p[0];
  unsigned char p2 = p[1];
   
  int read = 0;
  int ret = 0;
  if (p1 == 0xac && p2 == 0xed) {
    // skip magic, versions
    read += 4;
    ret = parse_contents(&p[4], len);
  } else {
    fprintf(stderr, "recieve not Java instance.\n");
  }
  return ret;
}

int parse_contents(unsigned char* p, u32 len) {
  unsigned char p1 = p[0];
  int advance = 0;
  switch (p1) {
    case TC_OBJECT: {
      advance = check_object(&p[1], len);
      
    }
  }
  return 1;
}

int check_object(unsigned char* p, u32 len) {
  unsigned char p1 = p[0];
  int advance = 1;
  switch (p1) {
    case TC_CLASSDESC: {
      advance += parse_classname(&p[advance], len);
      advance += parse_serializeUID(&p[advance], len);
      advance += parse_newHandle(&p[advance], len);
      break;
    }
    default: {
      fprintf(stderr, "not corresponding other symbols\n");
    }
  }

  return advance;
}

int parse_classname(unsigned char* p, u32 len) {
  int advance = 2;
  unsigned short classNameLen = (unsigned short)&p[0];
  printf("className => ");
  for (int i = 0; i < classNameLen; ++i) {
    printf("%c", (char)p[i+2]);
  }
  printf("\n");
  return advance + classNameLen;
}

int parse_serializeUID(unsigned char* p, u32 len) {
  // serializeUID <= long (8)
  printf("serializeUID size %ld => ", sizeof(long));
  for (int i = 0; i < sizeof(long); ++i) {
    printf("%02x ", p[i] & 0xff);
  }
  printf("\n");
  return sizeof(long);
}

int parse_newHandle(unsigned char* p, u32 len) {
  // newHandle <= assume 2bytes.
  int advance = sizeof(unsigned char);
  printf("newHandle => ");
  for (int i = 0; i < advance; ++i) {
    printf("%02x ", p[i] & 0xff);
  }
  printf("\n");
  return advance;
}

int parse_classDescInfo(unsigned char* p, u32 len) {
  // classDescFlags fields classAnnotation superClassDesc
  printf("classDeskFlags => %02x\n", p[0] & 0xff);
  int fieldCount = (int)p[1];

  int advance = 2;

  for (int i = 0; i < fieldCount; ++i) {
    
  }
}

int parse_classFieldData(unsigned char* p, u32 len) {
  int advance = 0;
  char prim_type = (char)p[advance++];
  if (prim_type == 'L' || prim_type == '[') {
    switch (prim_type) {
      case 'L': {
        int field_len = (unsigned short)&p[advance];
        advance += 2 + field_len;
        printf("field => ");
        for (int i = 0; i < field_len; ++i) {
          printf("%c", (char)p[i]);
        }
        printf("\n");
      }
    }
  } else {
    switch (prim_type) {
      case I: {
        
      }
    }
  }

  return advance;
}

struct MyTask parse_field(unsigned char* p, u32 len) {
  struct MyTask task;
  int j = 0;
  for (int i = len - 8; i < len; ++i) {
    task.str2[j++] = p[i]; 
  }
  j = 0;
  for (int i = len - 17 - 1; i < len - 10; ++i) {
    task.str1[j++] = p[i];
  }
  return task;
}

void construct_person(unsigned char* p1, unsigned char* p2, unsigned char* p) {
  {
    p[0] = 0xac;
    p[1] = 0xed;
    p[2] = 0x00;
    p[3] = 0x05;
    p[4] = 0x73;
    p[5] = 0x72;
    p[6] = 0x00;
    p[7] = 0x06;
    p[8] = 0x50;
    p[9] = 0x65;
    p[10] = 0x72;
    p[11] = 0x73;
    p[12] = 0x6f;
    p[13] = 0x6e;
    p[14] = 0x11;
    p[15] = 0x22;
  }

  {
    p[16] = 0x33;
    p[17] = 0x44;
    p[18] = 0x55;
    p[19] = 0x66;
    p[20] = 0x77;
    p[21] = 0x88;
    p[22] = 0x02;
    p[23] = 0x00;
    p[24] = 0x01;
    p[25] = 0x4c;
    p[26] = 0x00;
    p[27] = 0x04;
    p[28] = 0x6e;
    p[29] = 0x61;
    p[30] = 0x6d;
    p[31] = 0x65;
  }

  {
    p[32] = 0x74;
    p[33] = 0x00;
    p[34] = 0x12;
    p[35] = 0x4c;
    p[36] = 0x6a;
    p[37] = 0x61;
    p[38] = 0x76;
    p[39] = 0x61;
    p[40] = 0x2f;
    p[41] = 0x6c;
    p[42] = 0x61;
    p[43] = 0x6e;
    p[44] = 0x67;
    p[45] = 0x2f;
    p[46] = 0x53;
    p[47] = 0x74;
  }

  {
    p[48] = 0x72;
    p[49] = 0x69;
    p[50] = 0x6e;
    p[51] = 0x67;
    p[52] = 0x3b;
    p[53] = 0x78;
    p[54] = 0x70;
    p[55] = 0x74;
    p[56] = 0x00;
    p[57] = 0x10;
  }

  int cal = 58;
  for (int i = 0; i < 8; ++i) {
    p[cal++] = p1[i];
  }

  for (int i = 0; i < 8; ++i) {
    p[cal++] = p2[i];
  }
  
  hex_dump(p, cal - 1);
}

// newObject 
// TC_OBJECT classDesc newHandle classdata[]