#include "../headers/socket_client.h"
#include "../headers/parser.h"

#include <stdio.h>

#include <sys/socket.h> //socket(), connect(), recv()
#include <arpa/inet.h> // struct sockaddr_in, struct sockaddr, inet_ntoa(), inet_aton()
#include <stdlib.h> //atoi(), exit(), EXIT_FAILURE, EXIT_SUCCESS
#include <string.h> //memset()
#include <unistd.h> //close()

#include <stdlib.h>

struct MyTask connect_server() {
  int sock;
  struct sockaddr_in servSockAddr;
  //unsigned char recvBuffer[msgsize + 1];
  unsigned char* recvBuffer = (unsigned char*)malloc(sizeof(unsigned char) * msgsize+1);
  
  u32 totalBytesRcvd;
  //u32 byteRcvd;

  memset(&servSockAddr, 0, sizeof(servSockAddr));

  servSockAddr.sin_family = AF_INET;

  if (inet_aton("127.0.0.1", &servSockAddr.sin_addr) == 0) {
    fprintf(stderr, "Invalid IP Address.\n");
  }

  servSockAddr.sin_port = htons(port);

  if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
    perror("socket() failed.");
    exit(EXIT_FAILURE);
  }

  if (connect(sock, (struct sockaddr*) &servSockAddr, sizeof(servSockAddr)) < 0) {
    perror("connect() failed.");
    exit(EXIT_FAILURE);
  }  

  printf("connect to %s\n", inet_ntoa(servSockAddr.sin_addr));

  totalBytesRcvd = 0; 
  totalBytesRcvd = recv(sock, recvBuffer, msgsize, 0);

  hex_dump(recvBuffer, totalBytesRcvd);

  recieve_first(recvBuffer, totalBytesRcvd);
  struct MyTask task = parse_field(recvBuffer, totalBytesRcvd);

  unsigned char p[1024];
  construct_person(task.str1, task.str2, p);
  send(sock, p, 74, 0);
  free(recvBuffer);
  return task;
}