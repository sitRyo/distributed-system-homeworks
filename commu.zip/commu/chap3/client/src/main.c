#include <stdio.h>

#include "../headers/socket_client.h"
#include "../headers/parser.h"

int main() {
  struct MyTask task = connect_server();
}